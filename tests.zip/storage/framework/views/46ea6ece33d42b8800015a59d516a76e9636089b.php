<?php $__env->startSection('content'); ?>


                            
<div class="container">
    <div class="row">
     You are logged in!
                      <a href="<?php echo e(url('/logout')); ?>"  onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                Logout</a>
            
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>        

            <div class="col-sm-5">
            <label>Search By District:</label> 
            <form class="form-inline" method="post" action="<?php echo e(url('/search')); ?>">
                       <?php echo e(csrf_field()); ?>

                <select  name="district_involved"  class="form-control" required>
                                            <option value=""  disabled selected>--Select A District--</option>
                                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($district->district_name); ?>"><?php echo e($district->district_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                
                </select><br><br>
                <button  type="submit" class="btn btn-primary">Search</button>
            </form>
            </div>
            <div class="col-sm-5">
                <?php if($flag=='method1'): ?>
                    <h1>All Districts</h1>
                <?php else: ?> 
                    <h1><?php echo e($district_involved); ?>

                <?php endif; ?>
            </div>


        <div class="col-md-10"><br><br>
            <table class="table table-hover table1">
                <h3>Members Awaiting Approval:</h3><br>
                <thead><tr><td>S.N.</td><td>Name</td><td>Date of Birth</td><td>Created At</td><td>Involving District</td><td>Options</td></tr></thead>
                <?php $i=1;?>
                
                <tbody>
                <?php $__currentLoopData = $users->where('is_approved',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
               
                    <tr><td><?php echo e($i++); ?></td><td><?php echo e($user->name); ?></td><td><?php echo e($user->dob); ?></td><td><?php echo e($user->created_at->toDateString()); ?></td>
                        <td><?php echo e($user->district_involved); ?></td>
                        <td>
                            <a href="<?php echo e(url('/show', [$user->id])); ?>"><button class="btn btn-info">Show Details</button></a>
                            <a href="" class="approve" data-id="<?php echo $user->id;?>"><button class="btn btn-primary">Approve</button></a>
                            <a href="" class="delete" data-id="<?php echo $user->id;?>"><button class="btn btn-danger">Delete</button>                              
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>                
            </table>
        </div>
    </div>
</div>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-md-10">
            <table class="table table-hover table2">
                <h3>All Approved Members:</h3><br>
                <thead><tr><td>S.N.</td><td>Name</td><td>Date of Birth</td><td>Created At</td><td>Involving District</td><td>Options</td></tr></thead>
                <?php $i=1;?>
                
                <tbody>
                <?php $__currentLoopData = $users->where('is_approved',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
               
                    <tr><td><?php echo e($i++); ?></td><td><?php echo e($user->name); ?></td><td><?php echo e($user->dob); ?></td><td><?php echo e($user->created_at->toDateString()); ?></td>   <td><?php echo e($user->district_involved); ?></td><td>
                            <a href="<?php echo e(url('/show', [$user->id])); ?>"><button class="btn btn-info">Show Details</button></a>
                            <?php if($user->id != auth()->user()->id): ?>
                                <a href="" class="delete" data-id="<?php echo $user->id;?>"><button class="btn btn-danger">Delete</button>
                            <?php else: ?>
                                <a href="" class="delete" data-id="<?php echo $user->id;?>"><button class="btn btn-danger" disabled>Delete</button>
                            <?php endif; ?>                              
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </div>
</div>
    
<script>

$(document).on('click', '.delete', function (e) {
    e.preventDefault();
    var id = $(this).data('id');

    swal({
            title: "Are you sure you!",
            type: "error",
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes!",
            showCancelButton: true,
        },
        function() {
           $.ajax({
                type:"POST",
                url: "<?php echo e(url('/delete')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "id": id
                },

                success: function (data) {
                    var res=data;
                    if(res.status == true) {
                        swal("Member Removed", "", "success");
                        window.location.reload();
                    }
                }
            });
        },
        function() {
            window.location.reload();        }
    );
});


$(document).on('click', '.approve', function (e) {
    e.preventDefault();
    var id = $(this).data('id');

    swal({
            title: "Are you sure you!",
            type: "error",
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes!",
            showCancelButton: true,
        },
        function() {
           $.ajax({
                type:"POST",
                url: "<?php echo e(url('/approve')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "id": id
                },

                success: function (data) {
                    var res=data;
                    if(res.status == true) {
                        swal("Member Approved", "", "success");
                        window.location.reload();
                    }
                }
            });
        },
        function() {
            window.location.reload();        }
    );
});


$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

var table1=$('.table1').DataTable({
        "aLengthMenu": [[2, 5, 7, -1], [2, 5, 7, "All"]],
        "iDisplayLength": 2
    });


var table2=$('.table2').DataTable({
        "aLengthMenu": [[2, 5, 7, -1], [2, 5, 7, "All"]],
        "iDisplayLength": 5
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>