<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Update Form</div>

                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/update', [$user->id])); ?>">
                        <?php echo e(csrf_field()); ?>



                        <?php if(!empty($user->image)): ?>
                                
                        <div class="image">
                        <label class="col-md-4 control-label">Image</label>                            
                            <div class="col-md-6">
                                    <span class="close">&times;</span>
                                    <img width="100%" height="100%" src="<?php echo e(asset("public/newuploads/{$user->image}")); ?>"><br><br>
                            </div>
                        </div>

                        <?php else: ?>

                        <div class="uploadabc">
                            <label class="col-md-4 control-label">Upload Image</label>
                                <div class="col-md-6">
                                    <input  id="input-id" type="file" class="file" name="image" data-preview-file-type="text">
                                    <input type="hidden" id="getimagename" name="uploadedimage1" value="" ><br><br>    
                                </div>
                        </div>

                        <?php endif; ?>


                        <div class="upload">
                            <label class="col-md-4 control-label">Upload Image</label>
                                <div class="col-md-6">
                                    <input  id="input-id" type="file" class="file" name="image" data-preview-file-type="text">
                                    <input type="hidden" id="getimagename" name="uploadedimage" value="" ><br><br>    
                                </div>
                        </div>
                      

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('father_name') ? ' has-error' : ''); ?>">
                            <label for="father_name" class="col-md-4 control-label">Father's Name</label>

                            <div class="col-md-6">
                                    <input id="father_name" class="form-control" type="text" name="father_name" value="<?php echo e($user->father_name); ?>" required autofocus>
                                
                                <?php if($errors->has('father_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('father_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('mother_name') ? ' has-error' : ''); ?>">
                            <label for="mother_name" class="col-md-4 control-label">Mother's Name</label>

                            <div class="col-md-6">                                
                                    <input id="mother_name" class="form-control" type="text" name="mother_name" value="<?php echo e($user->mother_name); ?>" required autofocus>
                                
                                <?php if($errors->has('mother_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('mother_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
                            <label for="dob" class="col-md-4 control-label">Date Of Birth</label>

                            <div class="col-md-6">
                                <div class="input-group date">
                                    <input id="dob" class="form-control datepicker" placeholder="2012-02-12" type="text" name="dob" value="<?php echo e($user->dob); ?>" required autofocus>
                                    <div class="input-group-addon">
                                        <span class="glyphicon glyphicon-th"></span>
                                    </div>
                                </div>

                                <?php if($errors->has('dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Gender</label>

                            <div class="col-md-6">
                                <select class="form-control" name="gender"" required autofocus>
                                    <option value="<?php echo e($user->gender); ?>" selected><?php echo e($user->gender); ?></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>

                                <?php if($errors->has('gender')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                         <div class="form-group">
                            <fieldset>
                                <label class="col-md-4 control-label">Permanent Address</label><br>
                                    <div class="col-md-6">

                                            <label>Region:</label>
                                            <select  name="region" id="region" class="form-control" required>

                                            <option value="<?php echo e($user->region_id); ?>" selected><?php echo e($user->region->region_name); ?></option>
                                                <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($reg->id); ?>"><?php echo e($reg->region_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                
                                            </select><br>
                                                <?php if($errors->has('region')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('region')); ?></strong>
                                                    </span>
                                                <?php endif; ?>

                                            <label>Zone:</label>
                                                <select name="zone" id="zone" class="form-control zone" required> 

                                                <option value="<?php echo e($user->zone_id); ?>" selected><?php echo e($user->zone->zone_name); ?></option>
                                            </select><br>
                                              <?php if($errors->has('zone')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('zone')); ?></strong>
                                                    </span>
                                                <?php endif; ?>

                                            <label>District:</label>
                                                <select name="district" id="district"  class="form-control district" required>
                                                <option value="<?php echo e($user->district_id); ?>" selected><?php echo e($user->district->district_name); ?></option>
                                            </select><br>
                                                <?php if($errors->has('district')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('district')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                            <label>VDC/Municipality:</label>
                                                <input type="text" name="vdc_mun" value="<?php echo e($user->vdc_mun); ?>"  class="form-control vdc_mun" required>
                                            <br>
                                                <?php if($errors->has('vdc_mun')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('vdc_mun')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                             <label>Ward No.:</label>
                                                <input type="number" value="<?php echo e($user->ward_no); ?>"  name="ward_no" class="form-control ward_no" required>
                                            <br>

                                                <?php if($errors->has('ward_no')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('ward_no')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                    </div>
                            </fieldset>
                        </div>


                         <div class="form-group">
                            <fieldset>
                                <label class="col-md-4 control-label">Temporary Address</label><br>
                                    <div class="col-md-6">

                                            <label>Region:</label>
                                            <select  name="tregion" id="tregion"  class="form-control" required>
                                            <option value="<?php echo e($user->tregion_id); ?>" selected><?php echo e($user->tempRegion->region_name); ?></option>
                                                <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($reg->id); ?>"><?php echo e($reg->region_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                
                                            </select><br>
                                                <?php if($errors->has('tregion')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tregion')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                            <label>Zone:</label>
                                                <select name="tzone" id="tzone" class="form-control zone" required>
                                                <option value="<?php echo e($user->tzone_id); ?>" selected><?php echo e($user->tempZone->zone_name); ?></option>
                                            </select><br>
                                                 <?php if($errors->has('tzone')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tzone')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                            <label>District:</label>
                                                <select name="tdistrict" id="tdistrict" class="form-control district" required>
                                                    <option value="<?php echo e($user->tdistrict_id); ?>" selected><?php echo e($user->tempDistrict->district_name); ?></option>

                                            </select><br>
                                                <?php if($errors->has('tdistrict')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tdistrict')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            
                                            

                                            <label>VDC/Municipality:</label>
                                                <input type="text" value="<?php echo e($user->tvdc_mun); ?>" name="tvdc_mun" class="form-control vdc_mun">
                                            <br>
                                                <?php if($errors->has('tvdc_mun')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tvdc_mun')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                             <label>Ward No.:</label>
                                                <input type="number" value="<?php echo e($user->tward_no); ?>"  name="tward_no" class="form-control ward_no">
                                            <br>
                                             <?php if($errors->has('tward_no')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('tward_no')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            

                                    </div>
                            </fieldset>
                        </div>

                        <div class="form-group<?php echo e($errors->has('district_involved') ? ' has-error' : ''); ?>">
                            <label  class="col-md-4 control-label">Involving District</label>
                                <div class="col-md-6">
                                            <select  name="district_involved"  class="form-control" required>
                                            <option value="<?php echo e($user->district_involved); ?>"  selected><?php echo e($user->district_involved); ?></option>
                                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <option value="<?php echo e($district->district_name); ?>"><?php echo e($district->district_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                
                                            </select><br>
                                    <?php if($errors->has('district_involved')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('district_involved')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>                              
                        </div>
                     

                        <div class="form-group<?php echo e($errors->has('profession') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Profession and Workplace</label>
                            <div class="col-md-6">
                                <textarea class="form-control" name="profession" autofocus><?php if($user->profession): ?><?php echo e($user->profession); ?><?php endif; ?></textarea>
                                     <?php if($errors->has('profession')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('profession')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                            
                            </div>
                        </div>

                     
                        <div class="form-group<?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Contact Numbers</label><br>
                            <div class="col-md-6">
                                <label>Mobile:</label><br>
                                    <input type="number" value="<?php echo e($user->mobile); ?>"  name="mobile" class="form-control" required><br>
                                                <?php if($errors->has('mobile')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('mobile')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            
                                <label>Home Phone:</label><br>
                                    <input type="number" name="phone" value="<?php echo e($user->phone); ?>"  class="form-control"><br>
                                                <?php if($errors->has('phone')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            
                                <label>Office Phone:</label><br>
                                <input type="number" name="office_phone"  value="<?php echo e($user->office_phone); ?>" class="form-control"><br>
                                                <?php if($errors->has('office_phone')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('office_phone')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('refrence_name') ? ' has-error' : ''); ?>">
                            <label  class="col-md-4 control-label">Refrence Name</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" value="<?php echo e($user->refrence_name); ?>"  name="refrence_name" value="<?php echo e(old('refrence_name')); ?>" >

                                <?php if($errors->has('refrence_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('refrence_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                        <div class="form-group<?php echo e($errors->has('refrence_no') ? ' has-error' : ''); ?>">
                            <label  class="col-md-4 control-label">Refrence Membership Number</label>

                            <div class="col-md-6">
                                <input type="number" class="form-control" value="<?php echo e($user->refrence_no); ?>"  name="refrence_no" value="<?php echo e(old('refrence_no')); ?>" >

                                <?php if($errors->has('refrence_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('refrence_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div><br>

                        
                      

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Update
                                </button>
                            </div>
                        </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script type="text/javascript">
      $('.datepicker').datepicker({
      format: 'yyyy-mm-dd'
    });


$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

    $(document).on('change', '#region', function (e) {
          e.preventDefault();
          $.ajax({
            type:"POST",
            url:"<?php echo e(url('/getZone')); ?>",
            data:{id:$(this).val()},
            success: function(response){
              var res=response;

                      if(res.status == true)
                      {
                            var zone ='<option value="">--Select a Zone--</option>';
                            for(var i=0;  i<res.zone.length;  i++) 
                            {
                                zone += '<option value="' + res.zone[i].id + '">'+res.zone[i].zone_name+'</option>';
                                $('#zone').html(zone);                                                                    
                            }
                      }
                    }

                  });
        });

       $(document).on('change', '#zone', function (e) {
          e.preventDefault();

          $.ajax({
            type:"POST",
            url:"<?php echo e(url('/getDistrict')); ?>",
            data:{id:$(this).val()},
            success: function(response){
              var res=response;
              
                      if(res.status == true)
                      {
                            var district = '';
                            for(var i=0;  i<res.district.length;  i++) 
                            {
                                district += '<option value="'+ res.district[i].id+'">'+res.district[i].district_name+'</option>';
                                  $('#district').html(district);                                                                    
                            }
                      }
                    }

                  });
        });


        $('.upload').hide();
        $(document).on('click', '.close', function (e) {
          e.preventDefault();

            $('.upload').show();
            $('.image').hide();
        });



    $(document).on('change', '#tregion', function (e) {
          e.preventDefault();
          $.ajax({
            type:"POST",
            url:"<?php echo e(url('/getZone')); ?>",
            data:{id:$(this).val()},
            success: function(response){
              var res=response;

                      if(res.status == true)
                      {
                            var zone = '';
                            for(var i=0;  i<res.zone.length;  i++) 
                            {
                                zone += '<option value="' + res.zone[i].id + '">'+res.zone[i].zone_name+'</option>';
                                $('#tzone').html(zone);                                                                    
                            }
                      }
                    }

                  });
        });

       $(document).on('change', '#tzone', function (e) {
          e.preventDefault();

          $.ajax({
            type:"POST",
            url:"<?php echo e(url('/getDistrict')); ?>",
            data:{id:$(this).val()},
            success: function(response){
              var res=response;
              
                      if(res.status == true)
                      {
                            var district = '';
                            for(var i=0;  i<res.district.length;  i++) 
                            {
                                district += '<option value= "'+res.district[i].id+'">'+res.district[i].district_name+'</option>';
                                  $('#tdistrict').html(district);                                                                    
                            }
                      }
                    }

                  });
        });



$("#input-id").fileinput({
        maxFileSize: 24000,
        uploadUrl: "<?php echo e(url('/uploadimage')); ?>", // server upload action
        uploadAsync: true,
        allowedFileExtensions: ['jpg', 'png', 'gif', 'jpeg'],
        maxFileCount: 1,
        showUpload: true,
        dropZoneEnabled: true
});

// CATCH RESPONSE
$("#input-id").on('fileuploaderror', function(event, data, previewId, index) {
    var form = data.form, files = data.files, extra = data.extra,
        response = data.response, reader = data.reader;
    console.log(data.response.upload_error);
});

$("#input-id").on('fileuploaded', function(event, data, previewId, index) {
    var form = data.form, files = data.files, extra = data.extra,
        response = data.response, reader = data.reader;
    console.log(response);
    $('#getimagename').val(response);
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>