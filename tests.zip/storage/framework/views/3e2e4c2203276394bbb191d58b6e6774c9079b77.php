<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            
            <div class="panel panel-default">

                <div class="panel-body">
                    You are logged in!
                      <a href="<?php echo e(url('/logout')); ?>"  onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                Logout</a><br>
            
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form><br>
                            <a href="<?php echo e(url('/edit', [$user->id])); ?>"><button class="btn btn-info">Edit Profile</button></a><br>
                        <table class="table table-bordered"><br>
                            
                        
                        <h4><?php echo e($user->name); ?></h4>

                        <?php if(isset($user->image)): ?>
                            <img width="50%" height="50%" src="<?php echo e(asset("public/newuploads/{$user->image}")); ?>"><br><br>
                        <?php else: ?>
                            <img width="50%" height="50%" src="<?php echo e(asset('public/newuploads/nouploaded.bmp')); ?>"><br><br>
                        <?php endif; ?>
                        
                            <tr><td>1. </td><td>Name</td><td class="name" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/name')); ?>"><?php echo e($user->name); ?></td><tr>
                            
                            <tr><td>2. </td><td>Father's Name</td><td class="father_name" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/father_name')); ?>"><?php echo e($user->father_name); ?></td><tr>
                             
                            <tr><td>3. </td><td>Mother's Name</td><td class="mother_name" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/mother_name')); ?>"><?php echo e($user->mother_name); ?></td><tr>

                            <tr><td>4. </td><td>Date of Birth</td><td class="dob" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/dob')); ?>"><?php echo e($user->dob); ?></td><tr>

                            <tr><td>5. </td><td>Gender</td><td class="gender" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/gender')); ?>"><?php echo e($user->gender); ?></td><tr>

                            <tr><td>6.</td><td>Permanent Address</tr>
                            <tr><td> </td><td>Region</td><td class="region" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/region')); ?>"><?php echo e($user->region->region_name); ?></td><tr>

                            <tr><td> </td><td>Zone</td><td class="zone" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/zone')); ?>"><?php echo e($user->zone->zone_name); ?></td><tr>    
                            
                            <tr><td> </td><td>District</td><td class="district" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/district')); ?>"><?php echo e($user->district->district_name); ?></td><tr>

                            <tr><td> </td><td>VDC/Municipality</td><td class="vdc_mun" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/vdc_mun')); ?>"><?php echo e($user->vdc_mun); ?></td><tr>

                            <tr><td> </td><td>Ward Number</td><td class="ward_no" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/ward_no')); ?>"><?php echo e($user->ward_no); ?></td><tr>

                            <tr><td>7.</td><td>Temporary Address</tr>
                            <tr><td> </td><td>Region</td><td class="tregion" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/tregion')); ?>"><?php echo e($user->tempRegion->region_name); ?></td><tr>

                            <tr><td> </td><td>Zone</td><td class="tzone" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/tzone')); ?>"><?php echo e($user->tempZone->zone_name); ?></td><tr>    
                            
                            <tr><td> </td><td>District</td><td class="tdistrict" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/tdistrict')); ?>"><?php echo e($user->tempDistrict->district_name); ?></td><tr>

                             <tr><td> </td><td>VDV/Municipality</td><td class="tvdc_mun" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/tvdc_mun')); ?>"><?php echo e($user->tvdc_mun); ?></td><tr>

                             <tr><td> </td><td>Ward Number</td><td class="tward_no" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/tward_no')); ?>"><?php echo e($user->tward_no); ?></td><tr>

                            <tr><td>8. </td><td>Involving District</td><td class="district_involved" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/district_involved')); ?>"><?php echo e($user->district_involved); ?></td><tr>
                            

                            <tr><td>9.</td><td>Contact Numbers</tr>
                            <tr><td> </td><td>Mobile Number</td><td class="mobile" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/mobile')); ?>"><?php echo e($user->mobile); ?></td><tr>

                            <tr><td> </td><td>Home Phone</td><td class="phone" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/phone')); ?>"><?php echo e($user->phone); ?></td><tr>    
                            
                            <tr><td> </td><td>Office Phone</td><td class="office_phone" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/office_phone')); ?>"><?php echo e($user->office_pphone); ?></td><tr>

                            <tr><td>10. </td><td>Email</td><td class="email" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/email')); ?>"><?php echo e($user->email); ?></td><tr>

                            <tr><td>11. </td><td>Profession</td><td class="profession" data-pk="<?php echo auth()->user()->id;?>" data-url="<?php echo e(url('/edit/profession')); ?>"><?php echo e($user->profession); ?></td><tr>

                            <tr><td>12. </td><td>Membership Registration Date</td><td class="created_at" data-pk="<?php echo auth()->user()->id;?>" data-url=""><?php echo e($user->created_at); ?></td><tr>
                            
                            <tr><td>13. </td><td>Updated at</td><td class="updated_at" data-pk="<?php echo auth()->user()->id;?>" data-url=""><?php echo e($user->updated_at); ?></td><tr>
                            
                            
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>
    
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

// $.fn.editable.defaults.mode = 'inline'; //or popup

// $('.name').editable();
// $('.dob').editable();
// $('.father_name').editable();
// $('.mother_name').editable();

// $('.profession').editable();
// $('.email').editable();
// $('.phone').editable();
// $('.mobile').editable();
// $('.office_phone').editable();

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>